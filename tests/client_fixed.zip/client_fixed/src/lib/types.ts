export interface FileSystemItem {
    name: string;
    path: string;
    is_dir: boolean;
    has_children: boolean;
}

export interface FileSystemResponse {
    current: string;
    items: FileSystemItem[];
}

export interface TaskStatus {
    running: boolean;
    workers: number;
}

export interface TaskStartRequest {
    input_dir: string;
    dry_run: boolean;
    inplace: boolean;
    workers: number;
}

export const TYPES_VERSION = '1.0';
