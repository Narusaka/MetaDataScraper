
import { useEffect, useState } from 'react';
import { Save, Loader2, Key, Database, Image as ImageIcon, Monitor, Cpu } from 'lucide-react';
import { cn } from '../lib/utils';
import { useTranslation } from '../lib/language';
import { useTheme } from 'next-themes';
import { apiUrl } from '../lib/api';

// Loose typing for the config 
interface Config {
    tmdb?: { api_key: string };
    omdb?: { api_key: string };
    google?: { api_key: string; search_engine_id: string };
    model?: {
        base_url: string;
        api_key: string;
        model: string;
        temperature?: number;
    };
    output?: {
        image_limit?: {
            posters: number;
            backdrops: number;
        }
    }
    [key: string]: any;
}

export function SettingsView() {
    const { t, language, setLanguage } = useTranslation();
    const { theme, setTheme } = useTheme();
    const [config, setConfig] = useState<Config | null>(null);
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);
    const [workers, setWorkers] = useState(() => parseInt(localStorage.getItem('task_workers') || "4"));

    useEffect(() => {
        fetchSettings();
    }, []);

    const fetchSettings = async () => {
        setLoading(true);
        try {
            const res = await fetch(apiUrl('/api/settings'));
            if (res.ok) {
                const data = await res.json();
                setConfig(data);
            }
        } catch (e) {
            console.error("Failed to load settings", e);
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        if (!config) return;
        setSaving(true);
        setMsg(null);
        try {
            const res = await fetch(apiUrl('/api/settings'), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(config)
            });
            if (res.ok) {
                setMsg({ type: 'success', text: 'Settings saved successfully!' });
                setTimeout(() => setMsg(null), 3000);
            } else {
                setMsg({ type: 'error', text: 'Failed to save settings.' });
            }
        } catch (e) {
            setMsg({ type: 'error', text: 'Network error saving settings.' });
        } finally {
            setSaving(false);
        }
    };

    const updateConfig = (section: string, key: string, value: any) => {
        if (!config) return;
        setConfig(prev => {
            if (!prev) return null;
            return {
                ...prev,
                [section]: {
                    ...prev[section],
                    [key]: value
                }
            };
        });
    };

    if (loading && !config) {
        return <div className="flex justify-center p-12"><Loader2 className="animate-spin" /></div>;
    }


    if (!config) return <div>Error loading config.</div>;

    return (
        <div className="p-8 glass-panel-pro rounded-xl max-w-5xl mx-auto w-full mt-4 flex flex-col gap-8">
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="text-2xl font-bold flex items-center gap-3">
                        {t('settings')}
                    </h3>
                    <p className="text-sm text-secondary">Manage system preferences and API connections.</p>
                </div>
                <button
                    onClick={handleSave}
                    disabled={saving}
                    className="px-6 py-2 bg-primary hover:bg-primary/90 text-white rounded-lg font-medium flex items-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-primary/20"
                >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    Save Changes
                </button>
            </div>

            {msg && (
                <div className={cn(
                    "p-3 rounded-lg text-sm font-medium",
                    msg.type === 'success' ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"
                )}>
                    {msg.text}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

                {/* Column 1: Appearance & API */}
                <div className="space-y-8">

                    {/* UI Appearance */}
                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <SectionLabel icon={<Monitor />} label={t('nav_appearance')} />
                            <ProxyTester />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-xs text-secondary font-medium uppercase">Theme</label>
                                <div className="flex bg-black/10 rounded-lg p-1 border border-border/30">
                                    <button
                                        onClick={() => setTheme('light')}
                                        className={cn("flex-1 py-1.5 text-xs rounded transition-all", theme === 'light' ? "bg-white text-black shadow-sm" : "text-secondary hover:text-foreground")}
                                    >Light</button>
                                    <button
                                        onClick={() => setTheme('dark')}
                                        className={cn("flex-1 py-1.5 text-xs rounded transition-all", theme === 'dark' ? "bg-slate-700 text-white shadow-sm" : "text-secondary hover:text-foreground")}
                                    >Dark</button>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs text-secondary font-medium uppercase">Language</label>
                                <div className="flex bg-black/10 rounded-lg p-1 border border-border/30">
                                    <button
                                        onClick={() => setLanguage('en')}
                                        className={cn("flex-1 py-1.5 text-xs rounded transition-all", language === 'en' ? "bg-primary text-white shadow-sm" : "text-secondary hover:text-foreground")}
                                    >EN</button>
                                    <button
                                        onClick={() => setLanguage('zh')}
                                        className={cn("flex-1 py-1.5 text-xs rounded transition-all", language === 'zh' ? "bg-primary text-white shadow-sm" : "text-secondary hover:text-foreground")}
                                    >中文</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <SectionLabel icon={<Key />} label="API Keys" />
                        <div className="space-y-4">
                            <InputGroup
                                label="TMDB API Key"
                                value={config.tmdb?.api_key || ""}
                                onChange={(v) => updateConfig('tmdb', 'api_key', v)}
                                type="password"
                            />
                            <InputGroup
                                label="OMDB API Key"
                                value={config.omdb?.api_key || ""}
                                onChange={(v) => updateConfig('omdb', 'api_key', v)}
                                type="password"
                            />
                        </div>
                    </div>

                </div>

                {/* Column 2: LLM & Output & Execution */}
                <div className="space-y-8">

                    {/* Execution Settings (Client Side) */}
                    <div className="space-y-6">
                        <SectionLabel icon={<Cpu />} label="Task Execution" />
                        <div className="space-y-4">
                            <div className="glass-panel-pro bg-black/10 px-4 py-3 rounded-lg border border-border/30">
                                <div className="flex justify-between items-center mb-2">
                                    <label className="text-xs text-secondary font-medium uppercase">Thread Allocation</label>
                                    <span className="text-xs font-mono font-bold text-primary">
                                        {workers} CORES
                                    </span>
                                </div>
                                <input
                                    type="range" min="1" max="16"
                                    value={workers}
                                    onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        setWorkers(val);
                                        localStorage.setItem('task_workers', val.toString());
                                    }}
                                    className="w-full accent-primary h-1 bg-surface rounded-full appearance-none cursor-pointer"
                                />
                                <p className="text-[10px] text-muted-foreground mt-2">
                                    Determines how many concurrent scraping tasks run. Higher values require more CPU/RAM.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-6">
                        <SectionLabel icon={<Database />} label="LLM Configuration" />
                        <div className="space-y-4">
                            <InputGroup
                                label="Model Base URL"
                                value={config.model?.base_url || ""}
                                onChange={(v) => updateConfig('model', 'base_url', v)}
                                placeholder="http://localhost:8045/v1"
                            />
                            <InputGroup
                                label="Model API Key"
                                value={config.model?.api_key || ""}
                                onChange={(v) => updateConfig('model', 'api_key', v)}
                                placeholder="EMPTY"
                                type="password"
                            />
                            <InputGroup
                                label="Model Name"
                                value={config.model?.model || ""}
                                onChange={(v) => updateConfig('model', 'model', v)}
                                placeholder="gemini-3-flash"
                            />
                        </div>
                    </div>

                    <div className="space-y-6">
                        <SectionLabel icon={<ImageIcon />} label="Output Settings" />

                        <div className="flex gap-4">
                            <div className="flex-1">
                                <label className="text-xs text-secondary font-medium mb-1 block">Poster Limit</label>
                                <input
                                    type="number"
                                    className="w-full glass-panel-pro bg-black/10 px-3 py-2 rounded-lg border-border/30 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                                    value={config.output?.image_limit?.posters || 20}
                                    onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        setConfig(prev => ({
                                            ...prev!,
                                            output: {
                                                ...prev?.output,
                                                image_limit: {
                                                    ...prev?.output?.image_limit,
                                                    posters: val
                                                }
                                            }
                                        }))
                                    }}
                                />
                            </div>
                            <div className="flex-1">
                                <label className="text-xs text-secondary font-medium mb-1 block">Backdrop Limit</label>
                                <input
                                    type="number"
                                    className="w-full glass-panel-pro bg-black/10 px-3 py-2 rounded-lg border-border/30 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                                    value={config.output?.image_limit?.backdrops || 5}
                                    onChange={(e) => {
                                        const val = parseInt(e.target.value);
                                        setConfig(prev => ({
                                            ...prev!,
                                            output: {
                                                ...prev?.output,
                                                image_limit: {
                                                    ...prev?.output?.image_limit,
                                                    backdrops: val
                                                }
                                            }
                                        }))
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}

function SectionLabel({ icon, label }: { icon: any, label: string }) {
    return (
        <div className="flex items-center gap-2 text-primary border-b border-border/30 pb-2">
            <span className="w-5 h-5">{icon}</span>
            <h4 className="font-semibold">{label}</h4>
        </div>
    );
}

function InputGroup({ label, value, onChange, placeholder, type = "text" }: {
    label: string,
    value: string,
    onChange: (val: string) => void,
    placeholder?: string,
    type?: string
}) {
    return (
        <div className="space-y-1">
            <label className="text-xs text-secondary font-medium ml-1">{label}</label>
            <input
                type={type}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                placeholder={placeholder}
                className="w-full glass-panel-pro bg-black/10 px-4 py-2.5 rounded-lg border-border/30 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted/50"
            />
        </div>
    )
}

function ProxyTester() {
    const [status, setStatus] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    const check = async () => {
        setLoading(true);
        setStatus(null);
        try {
            const res = await fetch(apiUrl('/api/test_connectivity'));
            if (res.ok) {
                const data = await res.json();
                setStatus(data);
            } else {
                setStatus({ error: "API failed" });
            }
        } catch (e) {
            setStatus({ error: "Network error" });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col items-end gap-2">
            <button
                onClick={check}
                disabled={loading}
                className="text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg flex items-center gap-2 transition-all"
            >
                {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Monitor className="w-3 h-3" />}
                Test Connectivity
            </button>
            {status && (
                <div className="flex gap-2">
                    {['tmdb', 'google'].map(service => (
                        <div key={service} className={cn(
                            "px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-tighter border",
                            status[service]?.status === 'ok'
                                ? "bg-green-500/10 border-green-500/30 text-green-400"
                                : "bg-red-500/10 border-red-500/30 text-red-400"
                        )}>
                            {service}: {status[service]?.status || 'error'}
                        </div>
                    ))}
                    {status.error && <div className="text-[8px] text-red-400">{status.error}</div>}
                </div>
            )}
        </div>
    );
}

