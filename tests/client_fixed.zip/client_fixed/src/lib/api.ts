/**
 * Centralized API / WebSocket URL helpers.
 *
 * Default behavior:
 * - REST calls use relative paths ("/api/...") so they work behind reverse proxies.
 * - WebSocket calls use the current origin (window.location.host).
 *
 * Optional overrides (Vite env):
 * - VITE_API_BASE_URL: e.g. "http://localhost:8000" or "https://example.com"
 * - VITE_WS_BASE_URL:  e.g. "ws://localhost:8000" or "wss://example.com"
 */

const stripTrailingSlash = (s: string) => s.replace(/\/+$/, '');

export const API_BASE_URL = stripTrailingSlash(import.meta.env.VITE_API_BASE_URL ?? '');
export const WS_BASE_URL = stripTrailingSlash(import.meta.env.VITE_WS_BASE_URL ?? '');

export function apiUrl(path: string) {
  const p = path.startsWith('/') ? path : `/${path}`;
  return API_BASE_URL ? `${API_BASE_URL}${p}` : p;
}

export function wsUrl(path: string) {
  const p = path.startsWith('/') ? path : `/${path}`;
  if (WS_BASE_URL) return `${WS_BASE_URL}${p}`;
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}${p}`;
}
